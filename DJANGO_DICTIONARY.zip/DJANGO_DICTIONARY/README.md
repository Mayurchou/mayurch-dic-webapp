Since this dictionary uses API, installation of requests in terminal is required, run the below given code.
py -m pip install requests